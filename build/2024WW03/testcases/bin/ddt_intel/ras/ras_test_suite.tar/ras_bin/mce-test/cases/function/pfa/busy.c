#include <unistd.h>

int main()
{
	while (1)
		usleep(1000);
}
