#define err(x) perror(x), exit(1)
