# PMU and adaptive PEBS basic functional check

## Usage

1. Make sure latest perf is there.
2. Run case as
```
./pmu_tests.sh -t <case name>
./apebs_tests.sh -t <case name>
```

## Expected result

All test results should show pass, no fail.
